# VK Sender Bot package
